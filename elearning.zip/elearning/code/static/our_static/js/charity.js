$(document).ready(function(){
	//Navbar Fixed
    $(window).on('scroll', function() {
        if ($(document).scrollTop() > 150) {
            $('#head-nav.navbar').removeClass('p-3');
            $('#head-nav.navbar').addClass('fixed-top');
            $('#head-nav.navbar').addClass('pt-0 pl-2 pb-0 pr-2');

        } else {
            $('#head-nav.navbar').removeClass('fixed-top');
            $('#head-nav.navbar').removeClass('pt-0 pl-2 pb-0 pr-2');
            $('#head-nav.navbar').addClass('p-3');
        }
    });

	new WOW().init();

    //radio buttons on serach forms (rent or buy or all)
    $('#radioBtn a').on('click', function() {
        var sel = $(this).data('title');
        var tog = $(this).data('toggle');
        $('#'+tog).prop('value', sel);

        $('a[data-toggle="'+tog+'"]').not('[data-title="'+sel+'"]').removeClass('activ').addClass('notActive');
        $('a[data-toggle="'+tog+'"][data-title="'+sel+'"]').removeClass('notActive').addClass('activ');
        $('#final_answer').val(sel);
    });

    $('#submit_answer').click(function(event) {
        if ($("#final_answer").val() == "box") { 
            event.preventDefault();
            $("#correct_answer").modal('show');
        };
    });
    $('#submit_answer').click(function(event) {
        if ($("#final_answer").val() == "boy") { 
            event.preventDefault();
            $("#wrong_answer").modal('show');

        };
    });
})(jQuery);
from django import forms


class LoginForm(forms.Form):
	profile_email = forms.EmailField(max_length=100, required=True)
	profile_password = forms.CharField(required=True)

	profile_email = forms.EmailField(
		widget = forms.EmailInput(
			attrs={
				'required': True, 'class': 'form-control',
				'placeholder': 'Email'
			}
		)
	)

	profile_password = forms.CharField(
		widget = forms.PasswordInput(
			attrs={
				'required': True, 'class': 'form-control',
				'placeholder': 'Password'
			}
		)
	)

	class Meta:
		fields = ['profile_email', 'profile_password']

	def clean_profile_email(self):
		profile_email = self.cleaned_data['profile_email']
		return profile_email

	def clean_profile_password(self):
		profile_password = self.cleaned_data['profile_password']
		return profile_password
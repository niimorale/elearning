from django.apps import AppConfig


class EfieConfig(AppConfig):
    name = 'efie'

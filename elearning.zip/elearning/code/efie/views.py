from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

from ecourse.models import ECourse, ECourseTopic

# Create your views here.
def efie(request):
	if request.user.is_authenticated:
		return HttpResponseRedirect('/profile/')
	
	context = {
		"title": "Home",
	}
	return render(request, 'index.html', context)


def logout_user(request):
	if request.user.is_authenticated:
		logout(request)
		return HttpResponseRedirect('/')
	else:
		return HttpResponseRedirect('/')
	return render(request, "registration/logout.html", context)


@login_required(redirect_field_name='/accounts/login/')
def profile(request):
	subjects = ECourse.objects.all()

	context = {
		"title": "Profile",
		"subjects": subjects,
	}
	return render(request, "profile.html", context)


@login_required(redirect_field_name="/accounts/login/")
def subject_detail(request, slug):
	# subject_detail = ECourseTopic.objects.filter(detail_slug=detail_slug)
	subject_detail = ECourseTopic.objects.all()

	context = {
		"title": "Online Learning",
		"subject_detail": subject_detail,
	}
	return render(request, "subject-detail.html", context)


@login_required(redirect_field_name='/accounts/login/')
def course_detail(request, detail_slug):
	course_detail = ECourseTopic.objects.filter(detail_slug=detail_slug)

	context = {
		
		"course_detail": course_detail,
	}
	return render(request, "course-detail.html", context)
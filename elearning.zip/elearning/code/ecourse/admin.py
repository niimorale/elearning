from django.contrib import admin
from .models import ECourse, ECourseTopic

# Register your models here.
class ECourseAdmin(admin.ModelAdmin):
	list_display = ['subject_name', 'subject_tutor']


class ECourseTopicAdmin(admin.ModelAdmin):
	list_display = [
		'subject_name', 'course_topic', 
		'course_description', 'timestamp'
	]

admin.site.register(ECourse, ECourseAdmin)
admin.site.register(ECourseTopic, ECourseTopicAdmin)

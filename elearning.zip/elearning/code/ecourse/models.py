from django.db.models.signals import pre_save
from django.urls import reverse
from django.db import models

from .utils import unique_slug_generator, unique_slug_generator_2

# Create your models here.
class ECourse(models.Model):
	subject_name = models.CharField(max_length=50)
	subject_tutor = models.CharField(max_length=100)
	slug   = models.SlugField(null=True, blank=True, max_length=65)

	def __str__(self):
		return self.subject_name

	# def get_absolute_url(self):
	# 	return f"/{self.subject_name}"
	def get_absolute_url(self):
		return reverse('subject_detail', kwargs={'slug': self.slug})


def rl_pre_save_receiver(sender, instance, *args, **kwargs):
	instance.subject_name = instance.subject_name.title()
	if not instance.slug:
		instance.slug = unique_slug_generator(instance)
pre_save.connect(rl_pre_save_receiver, sender=ECourse)


## models for topics
class ECourseTopic(models.Model):
	subject_name = models.ForeignKey(ECourse, null=False, on_delete=models.CASCADE)
	course_topic = models.CharField(max_length=100)
	course_description = models.TextField(max_length=250)
	course_details = models.TextField(max_length=10000)
	detail_slug   = models.SlugField(null=True, blank=True, max_length=65)
	timestamp = models.DateTimeField('Upload on')

	class Meta:
		ordering = ['-timestamp']

	def __str__(self):
		return self.course_topic

	def get_absolute_url(self):
		return reverse('course_detail', kwargs={'detail_slug': self.detail_slug})

def rl_pre_save_receiver(sender, instance, *args, **kwargs):
	instance.course_topic = instance.course_topic.title()
	if not instance.detail_slug:
		instance.detail_slug = unique_slug_generator_2(instance)
pre_save.connect(rl_pre_save_receiver, sender=ECourseTopic)

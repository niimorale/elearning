from django.apps import AppConfig


class EcourseConfig(AppConfig):
    name = 'ecourse'

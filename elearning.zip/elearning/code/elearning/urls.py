"""elearning URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls import include
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path, reverse_lazy
from django.contrib.staticfiles.urls import static, staticfiles_urlpatterns

from efie.views import efie, profile, logout_user, course_detail, subject_detail

urlpatterns = [
	path('', efie, name="home"),
	path('accounts/logout/', logout_user, name="auth_logout"),
	path('accounts/login/', auth_views.LoginView.as_view(template_name='registration/login.html', redirect_field_name='profile'), name='auth_login'),
	path('password/reset/', auth_views.PasswordResetView.as_view(success_url=reverse_lazy('auth_password_reset_done')), name='auth_password_reset'),
	## course urls here
	path('profile/', profile, name="profile"),
	path('profile/<slug>/', subject_detail, name="subject_detail"),
	path('profile/course/detail/<detail_slug>/', course_detail, name="course_detail"),
	## end course urls
	
	# path('blog/', include('blog.urls')),
    path('admin/', admin.site.urls),
]

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

